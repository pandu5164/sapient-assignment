webpackHotUpdate(1,{

/***/ "./src/components/Home.js":
/*!********************************!*\
  !*** ./src/components/Home.js ***!
  \********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/classCallCheck */ "./node_modules/@babel/runtime/helpers/classCallCheck.js");
/* harmony import */ var _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @babel/runtime/helpers/createClass */ "./node_modules/@babel/runtime/helpers/createClass.js");
/* harmony import */ var _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @babel/runtime/helpers/assertThisInitialized */ "./node_modules/@babel/runtime/helpers/assertThisInitialized.js");
/* harmony import */ var _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @babel/runtime/helpers/inherits */ "./node_modules/@babel/runtime/helpers/inherits.js");
/* harmony import */ var _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @babel/runtime/helpers/possibleConstructorReturn */ "./node_modules/@babel/runtime/helpers/possibleConstructorReturn.js");
/* harmony import */ var _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @babel/runtime/helpers/getPrototypeOf */ "./node_modules/@babel/runtime/helpers/getPrototypeOf.js");
/* harmony import */ var _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "./node_modules/@babel/runtime/helpers/defineProperty.js");
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! react-redux */ "./node_modules/react-redux/lib/index.js");
/* harmony import */ var react_redux__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(react_redux__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! react-router-redux */ "./node_modules/react-router-redux/lib/index.js");
/* harmony import */ var react_router_redux__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_router_redux__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var react_waypoint__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! react-waypoint */ "./node_modules/react-waypoint/es/index.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! react-lazy-load */ "./node_modules/react-lazy-load/lib/LazyLoad.js");
/* harmony import */ var react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react_lazy_load__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../utils */ "./src/utils.js");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../constants */ "./src/constants.js");
/* harmony import */ var _presentations_Header__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../presentations/Header */ "./src/presentations/Header.js");
/* harmony import */ var _presentations_Footer__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ../presentations/Footer */ "./src/presentations/Footer.js");
/* harmony import */ var _actions_homeActions__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ../actions/homeActions */ "./src/actions/homeActions.js");
/* harmony import */ var _presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ../presentations/SvgLoading */ "./src/presentations/SvgLoading.js");
/* harmony import */ var _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ../assets/images/sapient.png */ "./src/assets/images/sapient.png");








function _createSuper(Derived) { var hasNativeReflectConstruct = _isNativeReflectConstruct(); return function _createSuperInternal() { var Super = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(Derived), result; if (hasNativeReflectConstruct) { var NewTarget = _babel_runtime_helpers_getPrototypeOf__WEBPACK_IMPORTED_MODULE_5___default()(this).constructor; result = Reflect.construct(Super, arguments, NewTarget); } else { result = Super.apply(this, arguments); } return _babel_runtime_helpers_possibleConstructorReturn__WEBPACK_IMPORTED_MODULE_4___default()(this, result); }; }

function _isNativeReflectConstruct() { if (typeof Reflect === "undefined" || !Reflect.construct) return false; if (Reflect.construct.sham) return false; if (typeof Proxy === "function") return true; try { Date.prototype.toString.call(Reflect.construct(Date, [], function () {})); return true; } catch (e) { return false; } }














var Home = /*#__PURE__*/function (_Component) {
  _babel_runtime_helpers_inherits__WEBPACK_IMPORTED_MODULE_3___default()(Home, _Component);

  var _super = _createSuper(Home);

  function Home(props) {
    var _this;

    _babel_runtime_helpers_classCallCheck__WEBPACK_IMPORTED_MODULE_0___default()(this, Home);

    _this = _super.call(this, props);

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleThumbnailLoadError", function (event) {
      event.target.src = _assets_images_sapient_png__WEBPACK_IMPORTED_MODULE_18__["default"];
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "isLaunched", function (event) {
      _this.setState({
        is_successful_launch: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "isLanded", function (event) {
      _this.setState({
        is_successful_land: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "selectedYear", function (event) {
      _this.setState({
        selected_launch: event.target.value
      });

      setTimeout(function () {
        _this.props.dispatch(Object(react_router_redux__WEBPACK_IMPORTED_MODULE_9__["push"])('/v3/launches?limit=100' + (_this.state.is_successful_launch ? '&launch_success=' + _this.state.is_successful_launch : '') + (_this.state.is_successful_land ? '&land_success=' + _this.state.is_successful_land : '') + (_this.state.selected_launch ? '&launch_year=' + _this.state.selected_launch : '')));

        _this.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this.state));
      });
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "listPaneDidMount", function (node) {
      if (node) {
        node.addEventListener('scroll', _this.handleListScroll);
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "handleListScroll", function (event) {
      var node = event.target;
      var bottom = node.scrollHeight - node.scrollTop === node.clientHeight;

      if (bottom) {
        // console.log('BOTTOM REACHED:', bottom);
        _this.fetchMoreCards();
      }
    });

    _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_6___default()(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this), "fetchMoreCards", function () {
      var total_item_count = _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_max; //this.props.homeApis.searchRestaurentsResultData.results_found;

      var current_number = _this.props.homeApis.launch_data && _this.props.homeApis.launch_data.length ? _this.props.homeApis.launch_data.length : 0;

      if (!_this.props.homeApis.searching_failed && (!totalItemCount || totalItemCount > _this.props.homeApis.launch_data.length)) {
        var temp_state = Object.assign({}, _this.state);
        temp_state.start_count = current_number;

        _this.setState(temp_state);
      }
    });

    _this.state = {
      codeBy: 'Pavan Kumar Z',
      total_results: _constants__WEBPACK_IMPORTED_MODULE_13__["default"].list_max,
      start_count: 0,
      launch_year: [2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020],
      is_successful_launch: null,
      is_successful_land: null,
      selected_launch: null,
      launch_values: ['true', 'false'],
      land_values: ['true', 'false']
    };
    _this.listPaneDidMount = _this.listPaneDidMount.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.handleListScroll = _this.handleListScroll.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.fetchMoreCards = Object(_utils__WEBPACK_IMPORTED_MODULE_12__["debounce"])(_this.fetchMoreCards, 500, _babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.isLanded = _this.isLanded.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.isLaunched = _this.isLaunched.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    _this.selectedYear = _this.selectedYear.bind(_babel_runtime_helpers_assertThisInitialized__WEBPACK_IMPORTED_MODULE_2___default()(_this));
    return _this;
  }

  _babel_runtime_helpers_createClass__WEBPACK_IMPORTED_MODULE_1___default()(Home, [{
    key: "componentDidMount",
    value: function componentDidMount() {
      var _this2 = this;

      if (this.props.location && this.props.location.query) {
        var launch_year = this.props.location.query.launch_year;
        var launch_success = this.props.location.query.launch_success;
        var land_success = this.props.location.query.land_success;
        this.setState({
          selected_launch: launch_year,
          is_successful_land: land_success,
          is_successful_launch: launch_success
        });
      }

      setTimeout(function () {
        _this2.props.dispatch(Object(_actions_homeActions__WEBPACK_IMPORTED_MODULE_16__["getLaunchData"])(_this2.state));
      }, 0);
    }
  }, {
    key: "renderData",
    value: function renderData(item, id) {
      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
        key: id
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(react_lazy_load__WEBPACK_IMPORTED_MODULE_11___default.a, {
        height: 75,
        offset: 500,
        once: true
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("img", {
        className: "rocketImg",
        alt: 'Rocket Logo',
        src: item.links.mission_patch_small,
        onError: this.handleThumbnailLoadError
      })), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, item.mission_name, " #", item.flight_number), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Mission Ids:")), item.mission_id && item.mission_id.length ? /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        className: "mission_id"
      }, item.mission_id.map(function (mis, i) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("li", {
          key: i
        }, mis, i == item.mission_id.length - 1 ? '.' : ', ');
      })) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, "N.A"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Launch Year:"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, item.launch_year)), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Successful Launch: "), item.launch_success ? 'True' : 'False'), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("p", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("b", null, "Successful Landing: "), item.rocket.first_stage.cores[0].land_success ? 'True' : 'False'));
    }
  }, {
    key: "render",
    value: function render() {
      var _this3 = this;

      return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", null, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "overlay",
        style: {
          display: this.props.homeApis.launchdata_searching ? "block" : "none"
        }
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "loading"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_SvgLoading__WEBPACK_IMPORTED_MODULE_17__["default"], null))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Header__WEBPACK_IMPORTED_MODULE_14__["default"], null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "left-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-data"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h1", null, "Filters"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Launch Year"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.launch_year.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id,
          style: {
            float: id == _this3.state.launch_year.length - 1 ? 'left' : 'none',
            width: id == _this3.state.launch_year.length - 1 ? '100%' : 'auto',
            paddingLeft: id == _this3.state.launch_year.length - 1 ? '5px' : '0'
          }
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "item"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.selectedYear(event);
          },
          name: "item",
          checked: item == _this3.state.selected_launch,
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, item)));
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Successful Launch"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.launch_values.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "launch"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.isLaunched(event);
          },
          checked: item == _this3.state.is_successful_launch,
          name: "launch",
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, id == 0 ? 'True' : 'False')));
      }))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h3", null, "Successful Landing"), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("hr", null), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "radio-toolbar"
      }, this.state.land_values.map(function (item, id) {
        return /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
          key: id
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("label", {
          htmlFor: "land"
        }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("input", {
          type: "radio",
          onChange: function onChange(event) {
            return _this3.isLanded(event);
          },
          checked: item == _this3.state.is_successful_land,
          name: "land",
          value: item
        }), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("span", null, id == 0 ? 'True' : 'False')));
      }))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("div", {
        className: "right-container"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("section", {
        className: "launch-data"
      }, /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("ul", {
        ref: this.listPaneDidMount,
        className: "rest-tiles"
        /*style={{ height: this.renderListHeight(), overflow: 'scroll' }}*/

      }, this.props.homeApis.launch_data.length ? this.props.homeApis.launch_data.map(function (item, id) {
        return _this3.renderData(item, id);
      }) : /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement("h2", null, "No Data Available"))))), /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_7___default.a.createElement(_presentations_Footer__WEBPACK_IMPORTED_MODULE_15__["default"], {
        developer: this.state.codeBy
      }));
    }
  }], [{
    key: "getDerivedStateFromProps",
    value: function getDerivedStateFromProps(props, state) {
      // for componentReceiveProps
      // console.log(props);
      if (props.homeApis.launchdata_searching_success && props.homeApis.launch_data) {
        //props.homeApis.fetchingLocationData &&
        // this.setState({locationData : props.homeApis.fetchedLocationData});
        state.launch_data = props.homeApis.launch_data;
      }

      return state;
    }
  }]);

  return Home;
}(react__WEBPACK_IMPORTED_MODULE_7__["Component"]);

function mapStateToProps(state) {
  return {
    homeApis: state.homeApis
  };
}

/* harmony default export */ __webpack_exports__["default"] = (Object(react_redux__WEBPACK_IMPORTED_MODULE_8__["connect"])(mapStateToProps)(Home));

/***/ })

})