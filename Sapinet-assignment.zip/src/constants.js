const constants = {
    base_api_url:'https://api.spaceXdata.com',
    api_point : '/v3',
    list_limit: 20,
    list_max:100,
    COLORS:{
        PUMPKIN_ORANGE:'#f57b02',
        HINT_OF_RED: '#F9F9F9',
        SCARLET: '#D0021B'
    }
}
export default constants;