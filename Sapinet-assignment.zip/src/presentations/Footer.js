import React from 'react';

export default function Footer(props) {
    return(<footer className="space-footer">
        <b>Developed by: {props.developer}</b>
        </footer>);
}
